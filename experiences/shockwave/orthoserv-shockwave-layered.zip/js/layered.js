'use strict';

// ORIGINAL photograph coordinates. Both product layers preserve original pixels.
// Only the flexible connecting hose is reconstructed as a live SVG curve.
const CONFIG = Object.freeze({
  original:{width:884,height:817},
  console:{
    crop:{x:188,y:244,width:696,height:468},plug:{x:606,y:703},
    mask:[[380,244],[835,260],[835,346],[884,351],[884,441],[850,459],[821,459],[711,674],[670,691],[635,692],[614,711],[593,706],[601,685],[244,642],[191,609],[188,579],[211,396]]
  },
  handpiece:{
    crop:{x:300,y:0,width:366,height:254},inlet:{x:310,y:174},tip:{x:645.32,y:224.675},axisDeg:40,coneDeg:38,
    mask:[[344,0],[413,0],[513,96],[614,165],[665,214],[665,254],[627,254],[472,170],[419,171],[368,147],[350,141],[325,171],[313,182],[301,171],[319,143],[333,121],[324,103],[322,70],[329,32]]
  },
  motion:{y:2.5,x:1.5,rotation:.25,period:8,pointer:2,recoil:.8,recoilDuration:.14},
  cable:{stiffness:42,damping:11,lagGain:.8,desktopBendX:.37,mobileBendX:.05},
  pulse:{delay:.6,interval:[1.4,.55],rings:[3,5],radius:[380,520],duration:1.9,stagger:.12,segments:28,alpha:.32,alphaBoost:.15,line:[2,.5],flashDuration:.16,flashRadius:17,glowBoost:.4},
  mobile:{breakpoint:640,interval:1.8,rings:2,radius:260},
  scroll:{distanceVh:160,scrub:.6,handpieceTravel:{x:10,y:-6,rotation:.6}},dprCap:2,orbitPeriod:90
});

(() => {
  const $=s=>document.querySelector(s),root=document.documentElement;
  const canvas=$('#pulseCanvas'),ctx=canvas.getContext('2d',{alpha:true});
  const art=$('#artwork'),hand=$('#handpieceMotion'),cable=$('#cableSvg'),path=$('#cablePath');
  const debug=new URLSearchParams(location.search).get('debug')==='1';
  const forceReduced=new URLSearchParams(location.search).get('motion')==='reduce';
  const reduced=matchMedia('(prefers-reduced-motion: reduce)'),mobile=matchMedia('(max-width: 639px)');
  const ar={};document.querySelectorAll('[data-copy]').forEach(el=>ar[el.dataset.copy]=el.textContent);
  Object.assign(ar,{resume:'تشغيل الحركة',static:'عرض ثابت · تمرير عادي',reduced:'عرض ثابت حسب تفضيل الحركة',mobile:'استكشف الجهاز بالتمرير',quoteTitle:'طلب عرض سعر — EMS DolorClast',quoteBody:'نقطة طلب عرض السعر للمراجعة. مسار الاستفسار الكامل يُبنى بعد اعتماد المشهد.',destination:'هذه الوجهة خارج نطاق المعاينة الحالية. المعروض هنا هو جهاز الشوك ويف فقط.',close:'إغلاق'});
  const en={skipContent:'Skip to content',products:'Products',services:'Services',business:'Business solutions',quote:'Request a quote',skipAnimation:'Skip animation',resume:'Enable animation',static:'Static view · native scrolling',reduced:'Static view · reduced motion',mobile:'Scroll to explore the device',headline1:'Radial shock wave therapy.',headline2:'Built for the clinic.',body:'EMS radial shock wave technology for physiotherapy clinics and rehabilitation centers.',explore:'Explore the device',authorized:'[Authorized distributor: to be confirmed]',registration:'[SFDA/MDMA No.: to be confirmed]',warranty:'[Warranty & service included: to be confirmed]',pulseCaption:'Illustration of radial pulses',demoNote:'Animation preview, not a treatment simulation.',scroll:'Scroll to build the pulse',deviceName:'Device',specifications:'Specifications',unconfirmed:'[To be confirmed]',availability:'Availability in Saudi Arabia',noSubmission:'Scene preview only. No requests are sent and no data is collected.',return:'Return to the scene',quoteTitle:'Request a quote — EMS DolorClast',quoteBody:'Quote entry for scene review. The full enquiry journey follows scene approval.',destination:'This destination is outside the current preview. Only the shock wave device is presented here.',close:'Close'};
  const s={lang:'ar',ready:false,inView:false,running:false,skipped:false,mobile:mobile.matches,reduced:reduced.matches||forceReduced,clock:0,next:.6,progress:{value:0},intensity:0,pulses:[],flash:-100,width:1,height:1,dpr:1,hp:null,body:null,pose:{x:0,y:0,r:0},spring:{x:0,y:0,vx:0,vy:0},pointer:{x:0,y:0},timeline:null,dialog:'quote',debugAt:0};
  const t=k=>(s.lang==='ar'?ar:en)[k]||ar[k]||k;
  const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
  const mix=(a,b,p)=>a+(b-a)*p;
  const axis=CONFIG.handpiece.axisDeg*Math.PI/180,cone=CONFIG.handpiece.coneDeg*Math.PI/180;

  function maskPhoto(id,part){
    const image=$(id),c=part.crop;
    image.style.inlineSize=`${CONFIG.original.width/c.width*100}%`;
    image.style.insetInlineStart=`${-c.x/c.width*100}%`;
    image.style.insetBlockStart=`${-c.y/c.height*100}%`;
    image.style.clipPath=`polygon(${part.mask.map(p=>`${p[0]/CONFIG.original.width*100}% ${p[1]/CONFIG.original.height*100}%`).join(',')})`;
  }
  maskPhoto('#consoleImage',CONFIG.console);maskPhoto('#handpieceImage',CONFIG.handpiece);

  function anchor(box,part,point,pose={x:0,y:0,r:0}){
    const px=(point.x-part.crop.x)/part.crop.width*box.w-box.w/2;
    const py=(point.y-part.crop.y)/part.crop.height*box.h-box.h/2;
    const rad=pose.r*Math.PI/180;
    return{x:box.x+box.w/2+px*Math.cos(rad)-py*Math.sin(rad)+pose.x,y:box.y+box.h/2+px*Math.sin(rad)+py*Math.cos(rad)+pose.y};
  }
  function measure(){
    const a=art.getBoundingClientRect(),hp=$('#handpieceBox').getBoundingClientRect(),body=$('#consoleBox').getBoundingClientRect();
    if(!a.width||!a.height)return;
    s.width=a.width;s.height=a.height;s.dpr=Math.min(devicePixelRatio||1,CONFIG.dprCap);
    s.hp={x:hp.x-a.x,y:hp.y-a.y,w:hp.width,h:hp.height};s.body={x:body.x-a.x,y:body.y-a.y,w:body.width,h:body.height};
    canvas.width=Math.round(a.width*s.dpr);canvas.height=Math.round(a.height*s.dpr);
    cable.setAttribute('viewBox',`0 0 ${a.width} ${a.height}`);
    const scale=clamp(body.width/CONFIG.console.crop.width,.40,1);
    const widths=[12,9,7,2.2,.6];cable.querySelectorAll('use').forEach((u,i)=>u.style.strokeWidth=String(widths[i]*scale));
    drawCable();if(!s.running)staticFrame();
  }
  function drawCable(){
    if(!s.hp||!s.body)return;
    const a=anchor(s.body,CONFIG.console,CONFIG.console.plug),b=anchor(s.hp,CONFIG.handpiece,CONFIG.handpiece.inlet,s.pose);
    const bendX=s.width*(s.mobile?CONFIG.cable.mobileBendX:CONFIG.cable.desktopBendX)+s.spring.x;
    const bendY=s.mobile?s.height*.49:s.height*.51+s.spring.y;
    // A weighted, relaxed hose: quiet behind the copy, responsive at the inlet.
    const d=`M ${a.x} ${a.y} C ${a.x-s.width*.035} ${a.y+s.height*.07}, ${bendX+s.width*.1} ${bendY+s.height*.22}, ${bendX} ${bendY} C ${bendX-s.width*.055} ${bendY-s.height*.12}, ${b.x-s.width*.065+s.spring.x} ${b.y+s.height*.12+s.spring.y}, ${b.x} ${b.y}`;
    path.setAttribute('d',d);
  }
  function clear(){if(!ctx)return;ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.setTransform(s.dpr,0,0,s.dpr,0,0);}
  function arc(origin,radius,alpha,width,u=0){
    if(!ctx)return;
    const direction=axis+s.pose.r*Math.PI/180;
    const red=Math.round(mix(21,191,u)),green=Math.round(mix(156,227,u)),blue=Math.round(mix(205,242,u));
    ctx.lineCap='round';ctx.lineWidth=width;
    for(let i=0;i<CONFIG.pulse.segments;i++){
      const v=(i+.5)/CONFIG.pulse.segments,angle=direction-cone+cone*2*v;
      const x=origin.x+Math.cos(angle)*radius,y=origin.y+Math.sin(angle)*radius;
      const edge=clamp(Math.min(s.width-x,s.height-y,x,y)/30);
      const opacity=alpha*Math.pow(Math.sin(v*Math.PI),1.35)*edge;if(opacity<.005)continue;
      ctx.strokeStyle=`rgba(${red},${green},${blue},${opacity})`;
      ctx.beginPath();ctx.arc(origin.x,origin.y,radius,direction-cone+cone*2*i/CONFIG.pulse.segments,direction-cone+cone*2*(i+1.06)/CONFIG.pulse.segments);ctx.stroke();
    }
  }
  function debugDraw(origin){
    if(!debug||!ctx)return;
    const direction=axis+s.pose.r*Math.PI/180;
    ctx.save();ctx.fillStyle='#d52163';ctx.strokeStyle='#d52163';ctx.lineWidth=1.3;ctx.setLineDash([4,5]);
    ctx.beginPath();ctx.moveTo(origin.x,origin.y);ctx.lineTo(origin.x+Math.cos(direction)*130,origin.y+Math.sin(direction)*130);ctx.stroke();
    [direction-cone,direction+cone].forEach(a=>{ctx.beginPath();ctx.moveTo(origin.x,origin.y);ctx.lineTo(origin.x+Math.cos(a)*160,origin.y+Math.sin(a)*160);ctx.stroke();});
    ctx.setLineDash([]);[origin,anchor(s.body,CONFIG.console,CONFIG.console.plug),anchor(s.hp,CONFIG.handpiece,CONFIG.handpiece.inlet,s.pose)].forEach(p=>{ctx.beginPath();ctx.arc(p.x,p.y,3.5,0,Math.PI*2);ctx.fill();});ctx.restore();
  }
  function staticFrame(){
    if(!s.hp||!s.body)return;
    s.pose={x:0,y:0,r:0};hand.style.transform='none';s.spring={x:0,y:0,vx:0,vy:0};drawCable();clear();
    const tip=anchor(s.hp,CONFIG.handpiece,CONFIG.handpiece.tip),scale=s.hp.w/CONFIG.handpiece.crop.width;
    if(s.reduced||s.skipped)[24,46,70].forEach((r,i)=>arc(tip,r*scale,.28-i*.05,1.4));debugDraw(tip);
  }
  function emit(){const p=CONFIG.pulse;s.pulses.push({born:s.clock,rings:s.mobile?CONFIG.mobile.rings:Math.round(mix(...p.rings,s.intensity)),radius:s.mobile?CONFIG.mobile.radius:mix(...p.radius,s.intensity),alpha:p.alpha*(1+p.alphaBoost*s.intensity)});s.flash=s.clock;}
  function frame(_time,delta){
    if(!s.hp)return;const dt=Math.min(delta/1000,.05);s.clock+=dt;
    const target=s.mobile?0:clamp(s.progress.value);s.intensity+=(target-s.intensity)*(1-Math.exp(-6*dt));
    if(s.clock>=s.next){emit();s.next=s.clock+(s.mobile?CONFIG.mobile.interval:mix(...CONFIG.pulse.interval,s.intensity));}
    const m=CONFIG.motion,p=CONFIG.pulse,travel=CONFIG.scroll.handpieceTravel;
    const age=s.clock-s.flash,recoil=age>=0&&age<m.recoilDuration?Math.sin(Math.PI*age/m.recoilDuration)*m.recoil:0;
    const amplitude=s.mobile?.28:1;
    s.pose={x:(Math.sin(s.clock*.73)*m.x+s.pointer.x*m.pointer)*amplitude-Math.cos(axis)*recoil+travel.x*s.intensity,y:(Math.sin(s.clock*Math.PI*2/m.period)*m.y+s.pointer.y*2)*amplitude-Math.sin(axis)*recoil+travel.y*s.intensity,r:Math.sin(s.clock*.65)*m.rotation*amplitude+travel.rotation*s.intensity};
    hand.style.transform=`translate3d(${s.pose.x}px,${s.pose.y}px,0) rotate(${s.pose.r}deg)`;
    const spring=s.spring,k=CONFIG.cable.stiffness,damping=CONFIG.cable.damping;
    spring.vx+=((s.pose.x*CONFIG.cable.lagGain-spring.x)*k-spring.vx*damping)*dt;spring.vy+=((s.pose.y*CONFIG.cable.lagGain-spring.y)*k-spring.vy*damping)*dt;spring.x+=spring.vx*dt;spring.y+=spring.vy*dt;
    drawCable();if(!s.mobile)$('#orbit').style.transform=`rotate(${s.clock*360/CONFIG.orbitPeriod}deg)`;clear();
    const tip=anchor(s.hp,CONFIG.handpiece,CONFIG.handpiece.tip,s.pose),scale=s.hp.w/CONFIG.handpiece.crop.width;
    s.pulses=s.pulses.filter(pulse=>s.clock-pulse.born<p.duration+(pulse.rings-1)*p.stagger);
    s.pulses.forEach(pulse=>{for(let ring=0;ring<pulse.rings;ring++){const elapsed=s.clock-pulse.born-ring*p.stagger;if(elapsed<0||elapsed>p.duration)continue;const u=elapsed/p.duration,ease=1-Math.pow(1-u,3);arc(tip,mix(12,pulse.radius,ease)*scale,pulse.alpha*(1-u),mix(...p.line,ease)*scale,ease);}});
    if(ctx&&age>=0&&age<p.flashDuration){const alpha=Math.sin(Math.PI*age/p.flashDuration)*p.alpha*(1+p.glowBoost*s.intensity),r=p.flashRadius*scale;const g=ctx.createRadialGradient(tip.x,tip.y,0,tip.x,tip.y,r);g.addColorStop(0,`rgba(245,254,255,${alpha})`);g.addColorStop(.3,`rgba(21,156,205,${alpha*.8})`);g.addColorStop(1,'rgba(21,156,205,0)');ctx.fillStyle=g;ctx.fillRect(tip.x-r,tip.y-r,r*2,r*2);}
    debugDraw(tip);
    if(debug&&s.clock-s.debugAt>.25){root.dataset.scrollProgress=s.progress.value.toFixed(3);root.dataset.pulseIntensity=s.intensity.toFixed(3);s.debugAt=s.clock;}
  }
  function sync(){
    const run=s.ready&&s.inView&&!document.hidden&&!s.skipped&&!s.reduced&&!!window.gsap&&!!ctx;
    root.dataset.animationRunning=String(run);if(run===s.running)return;s.running=run;
    if(run){s.next=s.clock+.6;gsap.ticker.add(frame);}else{if(window.gsap)gsap.ticker.remove(frame);s.pulses.length=0;staticFrame();}
  }
  function motionLabels(){const plain=s.reduced||s.skipped;root.classList.toggle('motion-static',plain);root.dataset.motionMode=s.reduced?'reduced':s.skipped?'skipped':s.mobile?'mobile':'desktop';$('#skipAnimation').disabled=s.reduced;$('#skipAnimation').setAttribute('aria-pressed',String(plain));$('#skipLabel').textContent=t(s.reduced?'reduced':s.skipped?'resume':'skipAnimation');$('#scrollLabel').textContent=t(plain?'static':s.mobile?'mobile':'scroll');}
  function setup(){
    if(s.timeline){s.timeline.scrollTrigger?.kill(true);s.timeline.kill();s.timeline=null;}
    s.mobile=mobile.matches;s.reduced=reduced.matches||forceReduced;s.progress.value=0;s.intensity=0;s.pulses.length=0;
    const hh=$('#header').getBoundingClientRect().height;root.style.setProperty('--header-size',`${hh}px`);measure();
    const canPin=!s.mobile&&$('#scene-1').offsetHeight<=innerHeight-hh+18;
    root.dataset.scrollPinned=String(canPin&&!s.skipped&&!s.reduced);
    if(!s.mobile&&!s.reduced&&!s.skipped&&window.gsap&&window.ScrollTrigger){gsap.registerPlugin(ScrollTrigger);s.timeline=gsap.to(s.progress,{value:1,ease:'none',duration:1,scrollTrigger:{id:'dolorclast-layered',trigger:'#scene-1',pin:canPin,start:()=>`top top+=${$('#header').getBoundingClientRect().height}`,end:()=>`+=${canPin?Math.round(innerHeight*1.6):Math.round($('#scene-1').offsetHeight*.7)}`,scrub:.6,invalidateOnRefresh:true}});}
    motionLabels();sync();if(!s.running)staticFrame();
  }
  function showDialog(kind){s.dialog=kind;$('#dialogTitle').textContent=kind==='device'?'EMS DolorClast':kind==='quote'?t('quoteTitle'):kind==='juzo'?'Juzo':t('services');$('#dialogBody').textContent=t(kind==='device'?'body':kind==='quote'?'quoteBody':'destination');$('#deviceDetails').hidden=kind!=='device';if(!$('#infoDialog').open)$('#infoDialog').showModal();}
  function translate(){root.lang=s.lang;root.dir=s.lang==='ar'?'rtl':'ltr';document.title=s.lang==='ar'?'OrthoServ — EMS DolorClast':'OrthoServ — DolorClast';document.querySelectorAll('[data-copy]').forEach(el=>el.textContent=t(el.dataset.copy));$('#language').setAttribute('aria-label',s.lang==='ar'?'Switch to English':'التبديل للعربية');$('#navigation').setAttribute('aria-label',s.lang==='ar'?'التنقل الرئيسي':'Main navigation');$('#trustRow').setAttribute('aria-label',s.lang==='ar'?'بيانات بانتظار التأكيد':'Information awaiting confirmation');$('#closeDialog').setAttribute('aria-label',t('close'));motionLabels();if(s.ready)setup();}
  $('#language').addEventListener('click',()=>{s.lang=s.lang==='ar'?'en':'ar';translate();});
  $('#skipAnimation').addEventListener('click',()=>{if(s.reduced)return;s.skipped=!s.skipped;setup();if(s.skipped)$('#scene-1').scrollIntoView({block:'start',behavior:'instant'});});
  document.addEventListener('click',e=>{if(e.target.closest('[data-quote]'))showDialog('quote');if(e.target.closest('[data-details]'))showDialog('device');const d=e.target.closest('[data-destination]');if(d)showDialog(d.dataset.destination);});
  $('#closeDialog').addEventListener('click',()=>$('#infoDialog').close());$('#returnButton').addEventListener('click',()=>$('#infoDialog').close());
  $('#scene-1').addEventListener('pointermove',e=>{if(s.mobile)return;s.pointer.x=clamp(e.clientX/innerWidth*2-1,-1,1);s.pointer.y=clamp(e.clientY/innerHeight*2-1,-1,1);});$('#scene-1').addEventListener('pointerleave',()=>{s.pointer={x:0,y:0};});
  new IntersectionObserver(entries=>{s.inView=entries[0].isIntersecting;sync();},{threshold:.01}).observe($('#scene-1'));
  new ResizeObserver(()=>measure()).observe(art);
  document.addEventListener('visibilitychange',sync);reduced.addEventListener('change',setup);mobile.addEventListener('change',setup);
  let timer;addEventListener('resize',()=>{clearTimeout(timer);timer=setTimeout(()=>{if(s.ready)setup();},160);});
  if(debug){$('#debugReadout').hidden=false;$('#debugReadout').textContent='Original tip: 645,225 · axis 40° · live anchors: inlet / tip / console plug';}
  Promise.all([$('#consoleImage'),$('#handpieceImage')].map(i=>i.decode?i.decode().catch(()=>{}):Promise.resolve())).then(()=>{s.ready=true;translate();if(!window.gsap||!window.ScrollTrigger||!ctx){s.skipped=true;setup();}if(document.fonts)document.fonts.ready.then(()=>{measure();if(window.ScrollTrigger)ScrollTrigger.refresh();});});
})();
